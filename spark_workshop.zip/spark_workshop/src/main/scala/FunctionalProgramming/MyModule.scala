package FunctionalProgramming

object MyModule {

  def abs(n:Int): Int = {
    if(n<0) -n
    else n
  }

  private def formsAbs(x:Int) = {
    val msg = "The absolute value of %d = %d"
    msg.format(x,abs(x))
  }

  def facorial(n:Int): Int  = {
    @ annotation.tailrec
    def go(n:Int,acc:Int):Int = {
      if(n<= 0) acc
      else go(n-1,acc*n)
    }
    go(n,1)
  }

  def nFibonacc(n:Int): Int ={
    def go(n:Int,acc:Int):Int = {
      if(n<= 0) acc
      else go(n-1,acc+n)
    }
    go(n,0)
  }

  def formatResult(name:String,n:Int,f:Int => Int) = {
    val msg = "The %s of %d = %d"
    msg.format(n,f(n))
  }

  def main(args: Array[String]): Unit = {
    println(formatResult("absolute value", -42, abs))
    println(formatResult("factorial", 7, facorial))
    println(formatResult("increment", 7, (x: Int) => x + 1))
    println(formatResult("increment2", 7, (x) => x + 1))
    println(formatResult("increment3", 7, x => x + 1))
    println(formatResult("increment4", 7, _ + 1))
    println(formatResult("increment5", 7, x => { val r = x + 1; r }))
  }

}
