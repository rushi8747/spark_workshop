package FunctionalProgramming

class ScalaMonoid{

  /*def mappend(a:Int,b:Int):Int = a+b
  def mazero:Int = 0
*/
}

object ScalaMonoid extends App {

  //def sum(xs:List[Int]):Int = xs.foldLeft(0)(_+_)
    def mappend(a:Int,b:Int):Int = a+b
    def mazero:Int = 0

  def sum(xs:List[Int]):Int = xs.foldLeft(ScalaMonoid.mazero)(ScalaMonoid.mappend)


  println(sum(List(1,2,3,4)))



}
