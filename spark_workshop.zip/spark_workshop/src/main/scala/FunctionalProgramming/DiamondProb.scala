package FunctionalProgramming

import scala.collection.mutable
import scala.collection.immutable

trait A{
  def show(): Unit ={
    println("A is shown")
  }
}

trait B extends A{
  override def show(): Unit = {
    println("B is shown")
  }
}

trait C extends A{
  override def show(): Unit = {
    println("C is shown")
  }
}

class D extends B with C with A {

}

object DiamondProb {

  def main(args: Array[String]): Unit = {

    val d = new D()
    println(d.show())

    var x: Set[Int] = immutable.Set[Int]()
    var y: mutable.Set[Int] = mutable.Set[Int]()

    x = x ++ Set(1,3,5,2,2,3,4)
    println(x)

    val str = "batmanstein"
      println(str.drop(3).take(3).capitalize)

    val s1 = "Homer"
    val s2 = "Ho" + "mer"
    println(s1 == s2)

  }
}
