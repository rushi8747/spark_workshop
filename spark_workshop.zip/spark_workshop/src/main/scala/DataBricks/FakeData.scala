package DataBricks

import org.apache.spark.rdd.RDD
import org.apache.spark.sql._
import org.apache.spark.sql.functions._
import org.apache.spark.sql.functions.regexp_extract
import java.util.regex.Pattern

import scala.util.matching.Regex

object FakeData {

  case class AccessLogRecord (
                               clientIpAddress: String,
                               rfc1413ClientIdentity: String,
                               remoteUser: String,
                               dateTime: String,
                               request: String,
                               httpStatusCode: String,
                               bytesSent: String,
                               referer: String,
                               userAgent: String
                             )

  def main(args: Array[String]): Unit = {

    val spark = SparkSession.builder.master("local").appName("SG").getOrCreate()
    import spark.implicits._

    val mySchema = Encoders.product[AccessLogRecord].schema
    //val parseLogDF = spark.read.option("sep"," ").schema(mySchema).csv("/databricks-datasets/learning-spark/data-001/fake_logs/log1.log")
    //val parseLogDS = parseLogDF.as[AccessLogRecord]


   val txtFile: RDD[String] =  spark.sparkContext.textFile("/home/rushi/IdeaProjects/spark_workshop/src/main/resources/databricks/fake_data.csv")

    txtFile.map{
      x => x.replace(" +0000]","")
          .replace("[","")
    }.foreach(println)



    def replaceChar(str:String,repl:String):String = str.replaceAll(repl,"")
    val fileRDD: RDD[String] = txtFile.map(replaceChar(_,"\\[")).map(replaceChar(_,"\\]")).map(_.replace(" +0000",""))

    val dss: DataFrame = fileRDD.map(_.split(" ")).map(x => AccessLogRecord(x(0), x(1), x(2), x(3), x(4), x(5), x(6), x(7), x(8) )).toDF()

    def applyREgex(col:Column):Column = {
      val patternString= "^(\\S+) (\\S+) (\\S+) \\[([\\w:/]+\\s[+\\-]\\d{4})\\] \"(\\S+) (\\S+) (\\S+)\" (\\d{3}) (\\d+)"
      regexp_replace(col,patternString,"")
    }

    //dss.withColumn("NewDate",applyREgex($"dateTime")).show()


    def removeUnwantedSpaces(str:String):String = {
      val patternString= "^(\\S+) (\\S+) (\\S+) \\[([\\w:/]+\\s[+\\-]\\d{4})\\] \"(\\S+) (\\S+) (\\S+)\" (\\d{3}) (\\d+)"
      str.replaceAll(patternString,"")
    }

    txtFile.map(removeUnwantedSpaces(_)).foreach(println)

  }


}
