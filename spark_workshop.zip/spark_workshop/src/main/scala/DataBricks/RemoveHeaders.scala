package DataBricks

import org.apache.spark.rdd.RDD
import org.apache.spark.{SparkConf, SparkContext}
import org.apache.spark.sql.{DataFrame, Row, SQLContext, SaveMode}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._
object RemoveHeaders {

  def main(args: Array[String]): Unit = {

    val conf = new SparkConf().setAppName("APB").setMaster("local")
    val sc = new SparkContext(conf)
    val ssc = new SQLContext(sc)
    import ssc.implicits._

    val full_csv: RDD[String] = sc.parallelize(Array(
      "col_1, col_2, col_3",
      "1, ABC, Foo1",
      "2, ABCD, Foo2"
 ))

    val header: Array[String] = full_csv.first().split(", ")


    //val regionString = "RegionKey1 name comment"







  }

}
