package DataBricks

import java.util.logging.Level
import java.util.logging.Logger
import java.util.regex.Matcher
import java.util.regex.Pattern

import org.apache.spark.sql.{Dataset, SparkSession}
object FakeDataSneh {

  case class AccessLog(ipAddress:String,clientIdentd:String,userID:String,dateTimeString:String,method:String,endpoint:String,protocol:String,responseCode:String,contentSize:String)

  def parseLogLine(logLine:String): AccessLog = {
    val LOG_ENTRY_PATTERN = "^(\\S+) (\\S+) (\\S+) \\[([\\w:/]+\\s[+\\-]\\d{4})\\] \"(\\S+) (\\S+) (\\S+)\" (\\d{3}) (\\d+)"
    val PATTERN = Pattern.compile(LOG_ENTRY_PATTERN)
    val m=PATTERN.matcher(logLine)
    AccessLog(m.group(1), m.group(2), m.group(3), m.group(4),m.group(5), m.group(6), m.group(7), m.group(8), m.group(9))
  }

  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder.master("local").appName("SG").getOrCreate()
    import spark.implicits._
    val out: Dataset[AccessLog] = spark.read.textFile("/home/rushi/IdeaProjects/spark_workshop/src/main/resources/databricks/fake_data.csv").map(parseLogLine).as[AccessLog]

    out.show()

  }

}
