package DataBricks

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql._

object DataBrick_LogProcess {

  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder.master("local").appName("SG").getOrCreate()
    import spark.implicits._
    val fakeDS: Dataset[Row] = spark.read.option("sep"," ")
      .option("sep","-").option("sep","  ").csv("/home/rushi/IdeaProjects/spark_workshop/src/main/resources/databricks/fake_data.csv").as("Fake")
    //fakeDS.show(3,false)

    val str = Seq((1,"R"), (2,"J"), (3,"L"))
    val df: DataFrame = spark.createDataFrame(str)

    val someDF = Seq(
      (8, "bat"),
      (64, "mouse"),
      (-27, "horse")
    ).toDF("number", "word")


  }

}
