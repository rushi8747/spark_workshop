package DataBricks

import org.apache.spark.rdd.RDD
import org.apache.spark.sql._
import org.apache.spark.sql.functions._
import org.apache.spark.sql.functions.regexp_extract
import java.util.regex.Pattern

import scala.util.matching.Regex

object FakeLogNewWay {
  case class AccessLogRecord (
                               clientIpAddress: String,
                               rfc1413ClientIdentity: String,
                               remoteUser: String,
                               dateTime: String,
                               request: String,
                               httpStatusCode: String,
                               bytesSent: String,
                               referer: String,
                               userAgent: String
                             )

  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder.master("local").appName("SG").getOrCreate()
    import spark.implicits._

    val mySchema = Encoders.product[AccessLogRecord].schema
    val logFile: Dataset[String] =  spark.read.textFile("/home/rushi/IdeaProjects/spark_workshop/src/main/resources/databricks/fake_data.csv")

    val splitlogDf: DataFrame = logFile.select(/*regexp_extract($"value","^([^\s]+\s)",1).alias("host"),*/
      regexp_extract($"value","^.*\\[(\\d\\d/\\w{3}/\\d{4}:\\d{2}:\\d{2}:\\d{2} -\\d{4})]",1).alias("timestamp"),
      regexp_extract($"value","^.*\"\\w+\\s+([^\\s]+)\\s+HTTP.*\"",1).alias("path"),
      regexp_extract($"value","^.*\"\\s+([^\\s]+)",1).alias("status"),
      regexp_extract($"value","^.*\\s+(\\d+)$",1).alias("content_size") )

    splitlogDf.show(2,false)





  }

}
