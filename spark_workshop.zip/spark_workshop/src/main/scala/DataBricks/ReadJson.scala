package DataBricks

import org.apache.spark.rdd.RDD
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{SQLContext, SparkSession}
import org.apache.spark.{SparkConf, SparkContext}
import org.apache.spark.util.SizeEstimator

object ReadJson {

  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder.master("local").appName("SG").getOrCreate()
    import spark.implicits._
    val jsonDf = spark.read.option("multiline", "true").json("/home/rushi/IdeaProjects/spark_workshop/src/main/resources/databricks/sample.json")
    jsonDf.printSchema()

    /*jsonDf.withColumn("batters",explode($"batters"))
      .withColumn("batter",$"batters"(0))
      .show(false)
*/
    println("The Size is :-- "+SizeEstimator.estimate(jsonDf))

    //val compSize = jsonDf.write.option("compression", "snappy").parquet("src/main/resources/databricks/parquet")


    println("The Parquet Format Size is :-- "+SizeEstimator.estimate(spark.read.parquet("src/main/resources/databricks/parquet/*.parquet")))

  }

}
