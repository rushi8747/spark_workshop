package DataBricks

import org.apache.spark.rdd.RDD
import org.apache.spark.sql._
import org.apache.spark.{SparkConf, SparkContext}

case class regioncase(
                   regionkey:Int,
                   name:String,
                   comment:String
                 )

case class nationcase(
                   nationKey:Int,
                   name:String,
                   regionKey:Int,
                   comment:String
                 )
object DataBricks {

  def main(args: Array[String]): Unit = {

    val conf = new SparkConf().setAppName("APB").setMaster("local")
    val sc = new SparkContext(conf)
    val ssc = new SQLContext(sc)

    val region: RDD[String] = sc.textFile("/home/rushi/IdeaProjects/spark_workshop/src/main/resources/databricks/region.csv")
    val nation = sc.textFile("/home/rushi/IdeaProjects/spark_workshop/src/main/resources/databricks/nation.csv")


    val regionRdd: RDD[Array[String]] = region.map(x => x.split("\\|"))
    val nationRdd: RDD[Array[String]] = nation.map(x => x.split("\\|"))

    val regionRDD: RDD[(Int, (String, String))] = regionRdd.map(x => regioncase(x(0).toInt,x(1),x(2))).map(x => ((x.regionkey),(x.comment,x.name)))
    val nationRDD = nationRdd.map(x => nationcase(x(0).toInt,x(1),x(2).toInt,x(3) ) ).map(x => (x.regionKey,x.nationKey))
    nationRDD.join(regionRDD).foreach(println)


    val spark = SparkSession.builder.master("local").appName("SG").getOrCreate()
  /*  val nationString = "nationKey name regionKey comment"
    val regionString = "RegionKey1 name comment"
    val nationschema = StructType(nationString.split(" ").map(fieldName => StructField(fieldName, StringType, nullable=true)))
    val regionschema = StructType(regionString.split(" ").map(fieldName => StructField(fieldName, StringType, nullable=true)))

    val nationDf = spark.read.option("sep","|").schema(nationschema).csv("/home/rushi/IdeaProjects/spark_workshop/src/main/resources/databricks/nation.csv")
    val regionDf = spark.read.option("sep","|").schema(regionschema).csv("/home/rushi/IdeaProjects/spark_workshop/src/main/resources/databricks/region.csv")

    regionDf.join(nationDf,regionDf.col("RegionKey1") === nationDf.col("regionKey")).select("regionKey","nationKey").show(5,false)*/
    /*val jsonDf = spark.read.json("/home/rushi/IdeaProjects/spark_workshop/src/main/resources/databricks/sample.json")
    val nestedDf = jsonDf.withColumn("batters",explode($"batters"))
      .withColumn("id",$"batters"(0))
      .withColumn("name",$"batters"(1)).show(3,false)*/


    /*
*/


  }


}
