package DataBricks

import org.apache.spark.rdd.RDD
import org.apache.spark.{SparkConf, SparkContext}
import org.apache.spark.sql.SQLContext


object ProcessCommaSep {

   def main(args: Array[String]): Unit = {

     val conf = new SparkConf().setAppName("APB").setMaster("local")
     val sc = new SparkContext(conf)
     val ssc = new SQLContext(sc)
     import ssc.implicits._


     val strRdd: RDD[String] = sc.textFile("/home/rushi/IdeaProjects/spark_workshop/src/main/resources/databricks/comma.csv")

     //strRdd.foreach(println)

     strRdd.map(_.split(", "))
       .flatMap(x =>  x.tail.grouped(2).map(y => (x.head, y.head))).foreach(println)



  }
}
