package RandomProg

import org.apache.spark.sql._
import org.apache.spark.sql.functions._
import org.apache.spark.sql.expressions.Window

object DataFrameEx {

  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder.master("local").appName("SG").getOrCreate()
    import spark.implicits._

    val regionString = "RegionKey1 name comment"

   val regionDf = spark.read.options(Map("header"->"true","sep"->","))
     .csv("/home/rushi/IdeaProjects/spark_workshop/src/main/resources/databricks/crfd_1365.csv")

    val filterDF:DataFrame = regionDf
      .filter(!(col("cli_flag")<=> "N" and(col("chd_creditbureau")<=>1)))
      .orderBy(col("Account_Id"))

    //filterDF.show()

    val groupedWithoutDf = filterDF
      .filter(!((col("chd_creditbureau")<=>2 ) and(col("cli_flag")<=>"N"))  ) // and(col("cli_flag")<=>"N")
      .withColumn("cnt", count("*").over(Window.partitionBy($"Account_Id")))
      .where($"cnt"===2).drop($"cnt")
      .show()
      //groupBy(col("Account_Id")).count()

   // groupedWithoutDf.show()
    /*val counDF: DataFrame = groupedWithoutDf
        .dropDuplicates(Seq("Account_Id"))
      /*.groupBy("Account_Id", "cli_flag")
      .count()
        .filter((col("count") <=> 2 and($"cli_flag"<=>"Y")   ))
        .drop("count")*/
      //  .withColumn("Elim",when($"count" <=>(2) and($"cli_flag"<=>"Y"),0 ).otherwise(1))
      //.select("Account_Id", "cli_flag","count")
    counDF.show()*/


    /*groupedWithoutDf.withColumn("cnt", count("*").over(Window.partitionBy($"Account_Id")))
      .where($"cnt"===2).drop($"cnt")
      .show()*/






  }

}
