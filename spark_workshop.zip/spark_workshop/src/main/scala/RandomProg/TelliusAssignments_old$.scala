import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.types._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions._

import scala.collection.immutable.{HashMap, ListMap}


object TelliusAssignments_old {

  val spark: SparkSession = SparkSession
    .builder()
    .master("local")
    .appName("Strategy Manager Executor")
    .getOrCreate()

  import spark.implicits._
  val schemaMap: HashMap[String, ListMap[String, DataType]] = HashMap(
    "customers" -> ListMap("customerId" -> IntegerType,
      "customerName" -> StringType),
    "products" -> ListMap("itemId" -> IntegerType,
      "category" -> StringType,
      "productNumber" -> IntegerType,
      "productName" -> StringType),
    "sales" -> ListMap("transactionId" -> IntegerType,
      "customerId" -> IntegerType,
      "itemId" -> IntegerType,
      "amount" -> IntegerType,
      "date" -> StringType)
  )

  def main(args: Array[String]): Unit = {

    val customersSchema = StructType(
      schemaMap
        .get("customers")
        .get
        .foldLeft(List[StructField]())((acc, input) =>
          acc :+ StructField(input._1, input._2, true)))
    val productsSchema = StructType(
      schemaMap
        .get("products")
        .get
        .foldLeft(List[StructField]())((acc, input) =>
          acc :+ StructField(input._1, input._2, true)))
    val salesSchema = StructType(
      schemaMap
        .get("sales")
        .get
        .foldLeft(List[StructField]())((acc, input) =>
          acc :+ StructField(input._1, input._2, true)))

    val salesDf = createDataFrame("src/main/resources/sales.csv")
    val customersDf = createDataFrame("src/main/resources/customers.csv")
    val productsDf = createDataFrame("src/main/resources/products.csv")

    val salesCount = getCount(salesDf)
    val customerCount = getCount(customersDf)
    val productsCount = getCount(productsDf)

    val nullHandle: DataFrame = nullHandler(salesDf)

    val joinedSalesWithCustomerProducst =
      joinWithProjection(salesDf, customersDf, productsDf)

    val result = addSequentialRowId(joinedSalesWithCustomerProducst)

    val getSalesByweek = salesByWeek(salesDf)
    val getSalesBydiscount = salesBydiscount(result)

    getSalesBydiscount.show

  }

  def getCount(dataFrame: DataFrame) = dataFrame.count()

  def createDataFrame(path: String) = {
    spark.read.option("header", true).option("inferschema", true).csv(path)
  }

  def joinWithProjection(salesDf: DataFrame,
                         customersDf: DataFrame,
                         productsDf: DataFrame): DataFrame = {
    val joinedSalesWithCustomerProduct = salesDf
      .join(customersDf, salesDf("customerId") === customersDf("customerId"))
      .join(productsDf, salesDf("itemId") === productsDf("itemId"))
      .select(customersDf("name") as ("customerName"),
        salesDf("date"),
        salesDf("customerId"),
        salesDf("itemId"),
        productsDf("category"),
        salesDf("amount"))

    joinedSalesWithCustomerProduct
  }

  def addSequentialRowId(dataFrame: DataFrame): DataFrame = {
    val w = Window.orderBy("customerName")
    val result = dataFrame.withColumn("id", row_number().over(w))
    result
  }

  def salesByWeek(dataFrame: DataFrame): DataFrame = {
    dataFrame
      .withColumn("weekly", weekofyear($"date"))
      .groupBy($"weekly")
      .sum("amount")
  }

  def nullHandler(dfWithNull: DataFrame) = {
    val dataTypeList = dfWithNull.dtypes

    dataTypeList.foldLeft(dfWithNull) {
      case (memodf, colNameType) =>
        if (!colNameType._2.contains("String") && !colNameType._2.contains(
          "Timestamp")) {
          memodf.withColumn(
            colNameType._1,
            when(col(colNameType._1).isNull,
              memodf
                .select(mean(colNameType._1))
                .first()(0)
                .asInstanceOf[Double]).otherwise(col(colNameType._1)))
        } else {
          memodf.withColumn(colNameType._1, col(colNameType._1))
        }
    }
  }

  def salesBydiscount(dataFrame: DataFrame): DataFrame = {
    dataFrame.withColumn("discount_amount", $"amount" * (0.95))
  }


}
