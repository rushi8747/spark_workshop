package RandomProg

object OOPScala {

  def main(args: Array[String]): Unit = {
    val nums = Array(6, 8, 3, 4, 1, 7)
    val words = List("Scala", "is", "fun", "to", "code", "in")

    nums.patch(5, Nil, 1).foreach(println)
println("-----------------")
    nums.patch(2, List(99, 98), 1).foreach(println)
    println("-----------------")
    nums.slice(2, 5).foreach(println)

    println(words.minBy(s => s(0)))


  }


}
