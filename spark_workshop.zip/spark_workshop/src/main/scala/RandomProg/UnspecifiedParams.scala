package RandomProg

case class Operator(operation: String)

case class MyCaseClass(left:Long, right: Option[Long] = None, operator: Option[Operator] = None)
case class UnspecifiedParams(
                                id:Int,
                                name:String,
                                rollId:Int
                            )

object UnspecifiedParams {
  def main(args: Array[String]): Unit = {

    val seqqq = Array(
      "NAB",
      "ABC",
    "PHA",
      "DJD"
    ).sorted

    val arrr = Array(
      "DJD",
      "ABC",
      "NAB",
      "PHA"
    ).sorted

    seqqq.foreach(println)
    if(seqqq.deep == arrr.deep) println("SAMMMEEE") else println("NNNNNNOOOOOOO")

    //assert(seqqq == arrr)


  }

}
