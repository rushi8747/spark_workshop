/*
package Trading;

import org.apache.commons.io.FileUtils;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

class DataCollection implements Runnable {
    private CountDownLatch latch;

    public DataCollection(CountDownLatch latch) {
        this.latch = latch;
    }

    @Override
    public void run() {
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        latch.countDown();
    }
}

public class TradePlus {
    private static final int FIFTEEN_MINUTES = 15 * 60 * 1000;
    private static final int THIRTY_SECONDS = 30 * 1000;
    private static ExecutorService executor1 = null;
    private static ExecutorService executor2 = null;
    private static volatile Future taskOneResults = null;
    private static volatile Future taskTwoResults = null;
    private static volatile Future taskThreeResults = null;
    private static volatile Future taskFourResults = null;
    private static volatile Future taskFiveResults = null;

    public static void main(String[] args) throws InterruptedException {
        executor1 = Executors.newFixedThreadPool(5);
        executor2 = Executors.newFixedThreadPool(1);
        System.out.println("Data Collection Started...");
//        Timer timer = new Timer();
//        TimerTask task = new TimerTask() {
//            @Override
//            public void run() {
//                System.out.println("Data Collection Completed, Analysis Started...");
//                timer.cancel();
//            }
//        };
//        timer.schedule(task, FIFTEEN_MINUTES);
        CountDownLatch latch = new CountDownLatch(1);
        executor2.submit(new DataCollection(latch));
        latch.await();
        while (true) {
            System.out.println("XXX");
            try {
                URL myURL = new URL("https://koinex.in/api/ticker");
                URLConnection myURLConnection = myURL.openConnection();
                BufferedReader in = new BufferedReader(new InputStreamReader(
                        myURLConnection.getInputStream()));
                myURLConnection.connect();
                String inputLine;
                while ((inputLine = in.readLine()) != null) {
                    JSONObject jsonObject = new JSONObject(inputLine);
                    JSONObject :q
                            = jsonObject.getJSONObject("stats");
                    JSONObject inrJSON = statsJSON.getJSONObject("inr");
                    jsonObject = new JSONObject(inrJSON.toString());
                    JSONObject xrpJSON = jsonObject.getJSONObject("XRP");
                    JSONObject ltcJSON = jsonObject.getJSONObject("LTC");
                    JSONObject ethJSON = jsonObject.getJSONObject("ETH");
//                    JSONObject bchJSON = jsonObject.getJSONObject("BCH");
                    JSONObject btcJSON = jsonObject.getJSONObject("BTC");
                    Utilities.writeToFile(String.valueOf(xrpJSON.getDouble("last_traded_price")), "XRP-ALL");
                    Utilities.writeToFile(String.valueOf(ltcJSON.getDouble("last_traded_price")), "LTC-ALL");
                    Utilities.writeToFile(String.valueOf(ethJSON.getDouble("last_traded_price")), "ETH-ALL");
//                    Utilities.writeToFile(String.valueOf(bchJSON.getDouble("last_traded_price")), "BCH-ALL");
                    Utilities.writeToFile(String.valueOf(btcJSON.getDouble("last_traded_price")), "BTC-ALL");
                    checkTasks(xrpJSON, ltcJSON, ethJSON, btcJSON);
                }
                in.close();
            } catch (MalformedURLException mue) {
                System.err.println("MalformedURL: " + mue.getMessage());
                mue.printStackTrace();
            } catch (IOException ioe) {
                System.err.println("IOException: " + ioe.getMessage());
                ioe.printStackTrace();
            }
            Thread.sleep(THIRTY_SECONDS);
        }
    }

    private static void checkTasks(JSONObject xrpJSON, JSONObject ltcJSON,
                                   JSONObject ethJSON, JSONObject btcJSON) {
        if (taskOneResults == null
                || taskOneResults.isDone()
                || taskOneResults.isCancelled()) {
            taskOneResults = executor1.submit(new xrpThread(xrpJSON));
        }
        if (taskTwoResults == null
                || taskTwoResults.isDone()
                || taskTwoResults.isCancelled()) {
            taskTwoResults = executor1.submit(new ltcThread(ltcJSON));
        }
        if (taskThreeResults == null
                || taskThreeResults.isDone()
                || taskThreeResults.isCancelled()) {
            taskThreeResults = executor1.submit(new ethThread(ethJSON));
        }
//        if (taskFourResults == null
//                || taskFourResults.isDone()
//                || taskFourResults.isCancelled()) {
//            taskFourResults = executor1.submit(new bchThread(bchJSON));
//        }
        if (taskFiveResults == null
                || taskFiveResults.isDone()
                || taskFiveResults.isCancelled()) {
            taskFiveResults = executor1.submit(new btcThread(btcJSON));
        }
    }
}

class xrpThread implements Runnable {
    private static final int FIFTEEN_MINUTES = 15 * 60 * 1000;
    private static final int BUCKET_SIZE = 30;
    static List<Double> xrpList = new ArrayList<>();
    double xrp;

    public xrpThread(JSONObject xrpJSON) {
        xrp = xrpJSON.getDouble("last_traded_price");
    }

    private static void addToList(Double element) {
        if (xrpList.size() >= BUCKET_SIZE) {
            xrpList.remove(0);
        }
        xrpList.add(element);
    }

    public void run() {
        addToList(xrp);
        if (xrpList.size() >= BUCKET_SIZE)
            listAnalysis();
    }

    private void listAnalysis() {
        for (int i = 0; i < xrpList.size(); i++) {
            for (int j = i + 1; j < xrpList.size(); j++) {
                if (xrpList.get(j) - xrpList.get(i) >= xrpList.get(i) * Utilities.XRP_PRFT / Utilities.XRP_INV) {
                    String str = Utilities.getTime() + " - XRP: " + xrpList.get(i) + " = " + xrpList.get(j) + " >>> Lele!!!";
                    System.out.println(str);
                    Utilities.writeToFile(str, "XRP");
                }
            }
        }
    }
}

class ltcThread implements Runnable {
    private static final int FIFTEEN_MINUTES = 15 * 60 * 1000;
    private static final int BUCKET_SIZE = 30;
    static List<Double> ltcList = new ArrayList<>();
    double ltc;

    public ltcThread(JSONObject ltcJSON) {
        ltc = ltcJSON.getDouble("last_traded_price");
    }

    private static void listAnalysis() {
        for (int i = 0; i < ltcList.size(); i++) {
            for (int j = i + 1; j < ltcList.size(); j++) {
                if (ltcList.get(j) - ltcList.get(i) >= ltcList.get(i) * Utilities.LTC_PRFT / Utilities.LTC_INV) {
                    String str = Utilities.getTime() + " - LTC: " + ltcList.get(i) + " = " + ltcList.get(j) + " >>> Lele!!!";
                    System.out.println(str);
                    Utilities.writeToFile(str, "LTC");
                }
            }
        }
    }

    private static void addToList(Double element) {
        if (ltcList.size() >= BUCKET_SIZE) {
            ltcList.remove(0);
        }
        ltcList.add(element);
    }

    public void run() {
        addToList(ltc);
        if (ltcList.size() >= BUCKET_SIZE)
            listAnalysis();
    }
}

class ethThread implements Runnable {
    private static final int FIFTEEN_MINUTES = 15 * 60 * 1000;
    private static final int BUCKET_SIZE = 30;
    static List<Double> ethList = new ArrayList<>();
    double eth;

    public ethThread(JSONObject ethJSON) {
        eth = ethJSON.getDouble("last_traded_price");
    }

    private static void listAnalysis() {
        for (int i = 0; i < ethList.size(); i++) {
            for (int j = i + 1; j < ethList.size(); j++) {
                if (ethList.get(j) - ethList.get(i) >= ethList.get(i) * Utilities.ETH_PRFT / Utilities.ETH_INV) {
                    String str = Utilities.getTime() + " - ETH: " + ethList.get(i) + " = " + ethList.get(j) + " >>> Lele!!!";
                    System.out.println(str);
                    Utilities.writeToFile(str, "ETH");
                }
            }
        }
    }

    private static void addToList(Double element) {
        if (ethList.size() >= BUCKET_SIZE) {
            ethList.remove(0);
        }
        ethList.add(element);
    }

    public void run() {
        addToList(eth);
        if (ethList.size() >= BUCKET_SIZE)
            listAnalysis();
    }
}

class btcThread implements Runnable {
    private static final int FIFTEEN_MINUTES = 15 * 60 * 1000;
    private static final int BUCKET_SIZE = 30;
    static List<Double> btcList = new ArrayList<>();
    double btc;

    public btcThread(JSONObject btcJSON) {
        btc = btcJSON.getDouble("last_traded_price");
    }

    private static void listAnalysis() {
        for (int i = 0; i < btcList.size(); i++) {
            for (int j = i + 1; j < btcList.size(); j++) {
                if (btcList.get(j) - btcList.get(i) >= btcList.get(i) * Utilities.BTC_PRFT / Utilities.BTC_INV) {
                    String str = Utilities.getTime() + " - BTC: " + btcList.get(i) + " = " + btcList.get(j) + " >>> Lele!!!";
                    System.out.println(str);
                    Utilities.writeToFile(str, "BTC");
                }
            }
        }
    }

    private static void addToList(Double element) {
        if (btcList.size() >= BUCKET_SIZE) {
            btcList.remove(0);
        }
        btcList.add(element);
    }

    public void run() {
        addToList(btc);
        if (btcList.size() >= BUCKET_SIZE)
            listAnalysis();
    }
}

class bchThread implements Runnable {
    private static final int FIFTEEN_MINUTES = 15 * 60 * 1000;
    private static final int BUCKET_SIZE = 30;
    static List<Double> bchList = new ArrayList<>();
    double bch;

    public bchThread(JSONObject bchJSON) {
        bch = bchJSON.getDouble("last_traded_price");
    }

    private static void listAnalysis() {
        for (int i = 0; i < bchList.size(); i++) {
            for (int j = i + 1; j < bchList.size(); j++) {
                if (bchList.get(j) - bchList.get(i) >= bchList.get(i) * Utilities.BCH_PRFT / Utilities.BCH_INV) {
                    String str = Utilities.getTime() + " - BCH: " + bchList.get(i) + " = " + bchList.get(j) + " >>> Lele!!!";
                    System.out.println(str);
                    Utilities.writeToFile(str, "BCH");
                }
            }
        }
    }

    private static void addToList(Double element) {
        if (bchList.size() >= BUCKET_SIZE) {
            bchList.remove(0);
        }
        bchList.add(element);
    }

    public void run() {
        addToList(bch);
        if (bchList.size() >= BUCKET_SIZE)
            listAnalysis();
    }
}

class Utilities {
    // these has to be user input in the app
    public static double DEFAULT_INV = 50000;
    public static double DEFAULT_PRFT = 3000;
    public static double XRP_INV = DEFAULT_INV;
    public static double XRP_PRFT = DEFAULT_PRFT;
    public static double ETH_INV = DEFAULT_INV;
    public static double ETH_PRFT = DEFAULT_PRFT;
    public static double LTC_INV = DEFAULT_INV;
    public static double LTC_PRFT = DEFAULT_PRFT;
    public static double BTC_INV = DEFAULT_INV;
    public static double BTC_PRFT = DEFAULT_PRFT;
    public static double BCH_INV = DEFAULT_INV;
    public static double BCH_PRFT = DEFAULT_PRFT;

    public static String getTime() {
        long ms = System.currentTimeMillis();
        SimpleDateFormat sdf = new SimpleDateFormat("MMM dd,yyyy HH:mm");
        Date date = new Date(ms);
        return sdf.format(date);
    }

    synchronized static void writeToFile(String str, String coin) {
        String directory = "src/main/resources/tradePlus/";
        String pathToFile = directory + coin + ".txt";
        File path = new File(pathToFile);
        try {
            FileUtils.writeStringToFile(path, str + "\n", true);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
*/
